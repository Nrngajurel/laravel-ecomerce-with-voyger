<?php

namespace App\Http\Controllers;

use App\Catagory;
use App\Product;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $productCatagories = Catagory::all();
        if (request()->category){
            $products = Product::with('catagories')->whereHas('catagories', function ($query){
                $query->where('slug',request()->category);
            })->latest()->paginate(3);
            $categoryName= request()->category;
//            dd($product);
        }else {
            $products = Product::take(12)->latest()->paginate(3);
            $categoryName= 'Features Items';

        }
        //dd($featuresitem);
        return view('public.shop')->with(
            ['products'=> $products,
            'productCatagories' => $productCatagories,
            'categoryName'=>$categoryName]
        );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  string  $slug
     * @return \Illuminate\Http\Response
     */
    public function show($slug)
    {
        $productCatagories = Catagory::all();
        $product= Product::where('slug',$slug)->firstOrFail();
        return view('public.Product')->with(
            ['product'=>$product,
            'productCatagories' => $productCatagories,]
        );
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
