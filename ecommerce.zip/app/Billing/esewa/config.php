<?php
$site_url = 'http://esewademo.nilambar.com.np/';
$esewa_url = 'http://dev.esewa.com.np/epay/main';
$esewa_verfication_url = 'http://dev.esewa.com.np/epay/transrec';
$merchant_id = "0000ETM";
?>