<?php
    require_once 'config.php';
?>
<h2><strong>ERROR:</strong> Payment cannot not be done.</h2>
<br/>
<a href="<?php echo $site_url; ?>">Go to homepage</a>