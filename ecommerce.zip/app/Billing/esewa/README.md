eSewa Payment Gateway implementation
====================================

eSewa payment gateway implementation in PHP

Demo
==
Click here to see [DEMO](http://esewademo.nilambar.com.np/)

Download Official Documentation
--
[Download](https://github.com/ernilambar/esewa-payment-gateway-implementation/blob/master/esewa%20epay_developer's%20guide_1.0.3.pdf?raw=true)
