<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CatagoryProduct extends Model
{
    protected $guarded=[];
    protected $table = 'catagory_product';
}
