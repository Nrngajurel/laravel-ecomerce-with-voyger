<?php

use Illuminate\Database\Seeder;
use App\Product;
class ProductsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Product::create(

        [
            'name'  =>'product1',
            'slug'  =>'product1',
            'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
            'price'  =>'1000',
            'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

        ]
        );
        Product::create(

            [
                'name'  =>'product2',
                'slug'  =>'product2',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
        Product::create(

            [
                'name'  =>'product3',
                'slug'  =>'product3',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
        Product::create(

            [
                'name'  =>'product4',
                'slug'  =>'product4',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
        Product::create(

            [
                'name'  =>'product5',
                'slug'  =>'product5',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
        Product::create(

            [
                'name'  =>'product6',
                'slug'  =>'product6',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
        Product::create(

            [
                'name'  =>'product7',
                'slug'  =>'product7',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
        Product::create(

            [
                'name'  =>'product8',
                'slug'  =>'product8',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
        Product::create(

            [
                'name'  =>'product9',
                'slug'  =>'product9',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
        Product::create(

            [
                'name'  =>'product10',
                'slug'  =>'product10',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
        Product::create(

            [
                'name'  =>'product11',
                'slug'  =>'product11',
                'short_description'  =>'orem ipsum dolor sit amet, consectetur adipisicing elit',
                'price'  =>'1000',
                'description'  =>'product1 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',

            ]
        );
    }
}
